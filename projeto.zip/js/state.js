/**
 * State Management
 * Sistema de gerenciamento de estado centralizado (Observer Pattern)
 */

class StateManager {
  constructor() {
    this.state = {
      // UI State
      sidebarOpen: !Utils.isMobile(),
      sidebarCollapsed: false,
      theme: 'light',
      loading: false,
      
      // Data State
      user: null,
      notifications: [],
      
      // Dashboard Data
      stats: {
        users: 0,
        revenue: 0,
        orders: 0,
        growth: 0
      },
      
      // Users
      users: [],
      currentUser: null,
      
      // Filters & Pagination
      filters: {
        search: '',
        sort: 'name',
        order: 'asc'
      },
      pagination: {
        page: 1,
        perPage: 10,
        total: 0
      }
    };
    
    this.observers = {};
    this.initialize();
  }

  /**
   * Initialize state from localStorage
   */
  initialize() {
    // Load theme
    const savedTheme = Utils.storage.get('theme');
    if (savedTheme) {
      this.setState({ theme: savedTheme });
      this.applyTheme(savedTheme);
    }
    
    // Load sidebar state
    const sidebarCollapsed = Utils.storage.get('sidebarCollapsed');
    if (sidebarCollapsed !== null) {
      this.setState({ sidebarCollapsed });
    }
    
    // Load user from session
    const user = Utils.storage.get('user');
    if (user) {
      this.setState({ user });
    }
  }

  /**
   * Get current state
   * @param {string} key - State key (optional)
   * @returns {*}
   */
  getState(key) {
    if (key) {
      return this.state[key];
    }
    return { ...this.state };
  }

  /**
   * Set state and notify observers
   * @param {Object} updates - State updates
   */
  setState(updates) {
    const prevState = { ...this.state };
    
    // Merge updates
    Object.keys(updates).forEach(key => {
      if (typeof updates[key] === 'object' && !Array.isArray(updates[key])) {
        this.state[key] = { ...this.state[key], ...updates[key] };
      } else {
        this.state[key] = updates[key];
      }
    });
    
    // Notify observers
    Object.keys(updates).forEach(key => {
      this.notify(key, this.state[key], prevState[key]);
    });
  }

  /**
   * Subscribe to state changes
   * @param {string} key - State key
   * @param {Function} callback - Callback function
   * @returns {Function} Unsubscribe function
   */
  subscribe(key, callback) {
    if (!this.observers[key]) {
      this.observers[key] = [];
    }
    
    this.observers[key].push(callback);
    
    // Return unsubscribe function
    return () => {
      this.observers[key] = this.observers[key].filter(cb => cb !== callback);
    };
  }

  /**
   * Notify observers of state change
   * @param {string} key - State key
   * @param {*} newValue - New value
   * @param {*} oldValue - Old value
   */
  notify(key, newValue, oldValue) {
    if (this.observers[key]) {
      this.observers[key].forEach(callback => {
        callback(newValue, oldValue);
      });
    }
  }

  /**
   * Toggle sidebar
   */
  toggleSidebar() {
    const collapsed = !this.state.sidebarCollapsed;
    this.setState({ sidebarCollapsed: collapsed });
    Utils.storage.set('sidebarCollapsed', collapsed);
  }

  /**
   * Toggle sidebar mobile
   */
  toggleSidebarMobile() {
    this.setState({ sidebarOpen: !this.state.sidebarOpen });
  }

  /**
   * Toggle theme
   */
  toggleTheme() {
    const newTheme = this.state.theme === 'light' ? 'dark' : 'light';
    this.setState({ theme: newTheme });
    this.applyTheme(newTheme);
    Utils.storage.set('theme', newTheme);
  }

  /**
   * Apply theme to document
   * @param {string} theme - Theme name
   */
  applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    
    // Update icon
    const icon = document.querySelector('#theme-toggle i');
    if (icon) {
      icon.className = theme === 'light' ? 'ti ti-moon' : 'ti ti-sun';
    }
  }

  /**
   * Set loading state
   * @param {boolean} loading - Loading state
   */
  setLoading(loading) {
    this.setState({ loading });
    
    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
      overlay.classList.toggle('active', loading);
    }
  }

  /**
   * Set user
   * @param {Object} user - User object
   */
  setUser(user) {
    this.setState({ user });
    if (user) {
      Utils.storage.set('user', user);
    } else {
      Utils.storage.remove('user');
    }
  }

  /**
   * Add notification
   * @param {Object} notification - Notification object
   */
  addNotification(notification) {
    const notifications = [...this.state.notifications, {
      id: Utils.generateId(),
      timestamp: new Date(),
      read: false,
      ...notification
    }];
    this.setState({ notifications });
  }

  /**
   * Mark notification as read
   * @param {string} id - Notification ID
   */
  markNotificationRead(id) {
    const notifications = this.state.notifications.map(n =>
      n.id === id ? { ...n, read: true } : n
    );
    this.setState({ notifications });
  }

  /**
   * Clear all notifications
   */
  clearNotifications() {
    this.setState({ notifications: [] });
  }

  /**
   * Update stats
   * @param {Object} stats - Stats object
   */
  updateStats(stats) {
    this.setState({ stats: { ...this.state.stats, ...stats } });
  }

  /**
   * Set users
   * @param {Array} users - Users array
   */
  setUsers(users) {
    this.setState({ 
      users,
      pagination: {
        ...this.state.pagination,
        total: users.length
      }
    });
  }

  /**
   * Set current user
   * @param {Object} user - User object
   */
  setCurrentUser(user) {
    this.setState({ currentUser: user });
  }

  /**
   * Update filters
   * @param {Object} filters - Filter updates
   */
  updateFilters(filters) {
    this.setState({ 
      filters: { ...this.state.filters, ...filters },
      pagination: { ...this.state.pagination, page: 1 } // Reset to first page
    });
  }

  /**
   * Update pagination
   * @param {Object} pagination - Pagination updates
   */
  updatePagination(pagination) {
    this.setState({ 
      pagination: { ...this.state.pagination, ...pagination }
    });
  }

  /**
   * Get filtered and paginated data
   * @returns {Object} { data, totalPages }
   */
  getFilteredUsers() {
    let filtered = [...this.state.users];
    
    // Apply search
    if (this.state.filters.search) {
      filtered = Utils.search(filtered, this.state.filters.search, ['name', 'email', 'role']);
    }
    
    // Apply sort
    filtered = Utils.sortBy(filtered, this.state.filters.sort, this.state.filters.order);
    
    // Apply pagination
    const paginated = Utils.paginate(
      filtered,
      this.state.pagination.page,
      this.state.pagination.perPage
    );
    
    return paginated;
  }

  /**
   * Reset state
   */
  reset() {
    this.state = {
      sidebarOpen: !Utils.isMobile(),
      sidebarCollapsed: false,
      theme: 'light',
      loading: false,
      user: null,
      notifications: [],
      stats: { users: 0, revenue: 0, orders: 0, growth: 0 },
      users: [],
      currentUser: null,
      filters: { search: '', sort: 'name', order: 'asc' },
      pagination: { page: 1, perPage: 10, total: 0 }
    };
    Utils.storage.clear();
  }
}

// Create global instance
window.State = new StateManager();