/**
 * Main Application Script
 * Inicialização e event handlers principais
 */

(function() {
  'use strict';

  /**
   * Initialize application
   */
  function init() {
    console.log('🚀 Tabler Dashboard initialized');

    // Setup sidebar
    setupSidebar();

    // Setup theme toggle
    setupThemeToggle();

    // Setup mobile menu
    setupMobileMenu();

    // Setup notifications
    setupNotifications();

    // Subscribe to state changes
    subscribeToState();

    // Initialize tooltips
    initializeTooltips();

    // Show welcome toast
    setTimeout(() => {
      Components.toast({
        type: 'success',
        title: 'Bem-vindo!',
        message: 'Dashboard carregado com sucesso.'
      });
    }, 500);
  }

  /**
   * Setup sidebar functionality
   */
  function setupSidebar() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebar-toggle');

    if (!sidebar || !sidebarToggle) return;

    // Apply saved state
    if (State.getState('sidebarCollapsed')) {
      sidebar.classList.add('collapsed');
    }

    // Toggle sidebar
    sidebarToggle.addEventListener('click', () => {
      State.toggleSidebar();
    });

    // Subscribe to sidebar state changes
    State.subscribe('sidebarCollapsed', (collapsed) => {
      sidebar.classList.toggle('collapsed', collapsed);
    });
  }

  /**
   * Setup theme toggle
   */
  function setupThemeToggle() {
    const themeToggle = document.getElementById('theme-toggle');
    if (!themeToggle) return;

    themeToggle.addEventListener('click', () => {
      State.toggleTheme();
    });
  }

  /**
   * Setup mobile menu
   */
  function setupMobileMenu() {
    const mobileToggle = document.getElementById('mobile-menu-toggle');
    const sidebar = document.getElementById('sidebar');
    
    if (!mobileToggle || !sidebar) return;

    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    document.body.appendChild(overlay);

    // Toggle mobile menu
    mobileToggle.addEventListener('click', () => {
      sidebar.classList.toggle('mobile-open');
      overlay.classList.toggle('active');
    });

    // Close on overlay click
    overlay.addEventListener('click', () => {
      sidebar.classList.remove('mobile-open');
      overlay.classList.remove('active');
    });

    // Close on navigation
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        if (Utils.isMobile()) {
          sidebar.classList.remove('mobile-open');
          overlay.classList.remove('active');
        }
      });
    });
  }

  /**
   * Setup notifications
   */
  function setupNotifications() {
    const notificationBtn = document.querySelector('.header-actions .btn-icon:has(.ti-bell)');
    if (!notificationBtn) return;

    notificationBtn.addEventListener('click', () => {
      const notifications = State.getState('notifications');
      
      if (notifications.length === 0) {
        Components.toast({
          type: 'info',
          message: 'Você não tem notificações no momento.'
        });
        return;
      }

      const content = `
        <div class="notifications-list">
          ${notifications.map(n => `
            <div class="notification-item ${n.read ? 'read' : ''}">
              <div class="notification-content">
                <strong>${n.title}</strong>
                <p>${n.message}</p>
                <small class="text-muted">${Utils.formatRelativeTime(n.timestamp)}</small>
              </div>
            </div>
          `).join('')}
        </div>
      `;

      Components.modal({
        title: 'Notificações',
        content,
        footer: `
          <button class="btn btn-ghost" onclick="State.clearNotifications(); Components.closeModal(this.closest('.modal').id)">
            Limpar Todas
          </button>
        `
      });
    });
  }

  /**
   * Subscribe to important state changes
   */
  function subscribeToState() {
    // Log state changes in development
    if (window.location.hostname === 'localhost') {
      State.subscribe('user', (user) => {
        console.log('User changed:', user);
      });

      State.subscribe('loading', (loading) => {
        console.log('Loading:', loading);
      });
    }
  }

  /**
   * Initialize tooltips
   */
  function initializeTooltips() {
    // Add data-tooltip attributes to nav links for collapsed sidebar
    document.querySelectorAll('.nav-link').forEach(link => {
      const span = link.querySelector('span');
      if (span) {
        link.setAttribute('data-tooltip', span.textContent);
      }
    });
  }

  /**
   * Handle global errors
   */
  window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
    
    Components.toast({
      type: 'error',
      title: 'Erro',
      message: 'Ocorreu um erro inesperado. Por favor, recarregue a página.',
      duration: 0,
      closable: true
    });
  });

  /**
   * Handle unhandled promise rejections
   */
  window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled rejection:', event.reason);
    
    Components.toast({
      type: 'error',
      title: 'Erro',
      message: 'Falha ao processar requisição.',
      duration: 5000
    });
  });

  /**
   * Cleanup before page unload
   */
  window.addEventListener('beforeunload', () => {
    // Save any pending state
    console.log('Cleaning up...');
  });

  /**
   * Handle online/offline events
   */
  window.addEventListener('online', () => {
    Components.toast({
      type: 'success',
      title: 'Online',
      message: 'Conexão restabelecida.'
    });
  });

  window.addEventListener('offline', () => {
    Components.toast({
      type: 'warning',
      title: 'Offline',
      message: 'Você está sem conexão com a internet.',
      duration: 0,
      closable: true
    });
  });

  /**
   * Keyboard shortcuts
   */
  document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + K - Search (example)
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
      e.preventDefault();
      Components.toast({
        type: 'info',
        message: 'Busca rápida (Funcionalidade em desenvolvimento)'
      });
    }

    // Ctrl/Cmd + B - Toggle sidebar
    if ((e.ctrlKey || e.metaKey) && e.key === 'b') {
      e.preventDefault();
      State.toggleSidebar();
    }

    // Ctrl/Cmd + T - Toggle theme
    if ((e.ctrlKey || e.metaKey) && e.key === 't') {
      e.preventDefault();
      State.toggleTheme();
    }
  });

  /**
   * Add ripple effect to buttons
   */
  document.addEventListener('click', (e) => {
    const button = e.target.closest('.btn, .btn-icon');
    if (button && button.classList.contains('ripple-container')) {
      Utils.addRipple(button, e);
    }
  });

  /**
   * Performance monitoring
   */
  if (window.performance && window.performance.timing) {
    window.addEventListener('load', () => {
      setTimeout(() => {
        const perfData = window.performance.timing;
        const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
        console.log(`📊 Page load time: ${pageLoadTime}ms`);
      }, 0);
    });
  }

  /**
   * Development helpers
   */
  if (window.location.hostname === 'localhost') {
    // Expose globals for debugging
    window.debug = {
      state: State,
      api: API,
      utils: Utils,
      components: Components,
      router: router
    };

    console.log('🔧 Debug mode enabled. Access via window.debug');
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();