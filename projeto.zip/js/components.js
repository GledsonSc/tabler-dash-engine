/**
 * UI Components
 * Componentes reutilizáveis para construção da interface
 */

const Components = {
  /**
   * Show toast notification
   * @param {Object} options - Toast options
   */
  toast(options = {}) {
    const {
      title = '',
      message = '',
      type = 'info', // success, error, warning, info
      duration = 4000,
      closable = true
    } = options;

    const container = document.getElementById('toast-container');
    if (!container) return;

    const id = Utils.generateId();
    const icons = {
      success: 'ti-check',
      error: 'ti-x',
      warning: 'ti-alert-triangle',
      info: 'ti-info-circle'
    };

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.id = id;
    toast.innerHTML = `
      <div class="toast-icon">
        <i class="ti ${icons[type]}"></i>
      </div>
      <div class="toast-content">
        ${title ? `<div class="toast-title">${title}</div>` : ''}
        <div class="toast-message">${message}</div>
      </div>
      ${closable ? '<button class="toast-close" aria-label="Close"><i class="ti ti-x"></i></button>' : ''}
    `;

    container.appendChild(toast);

    // Close button
    if (closable) {
      const closeBtn = toast.querySelector('.toast-close');
      closeBtn.addEventListener('click', () => this.closeToast(id));
    }

    // Auto close
    if (duration > 0) {
      setTimeout(() => this.closeToast(id), duration);
    }

    return id;
  },

  /**
   * Close toast
   * @param {string} id - Toast ID
   */
  closeToast(id) {
    const toast = document.getElementById(id);
    if (!toast) return;

    toast.classList.add('removing');
    setTimeout(() => toast.remove(), 300);
  },

  /**
   * Show modal
   * @param {Object} options - Modal options
   */
  modal(options = {}) {
    const {
      title = '',
      content = '',
      footer = '',
      size = 'md', // sm, md, lg
      closable = true,
      onClose = null
    } = options;

    const id = Utils.generateId();
    const container = document.getElementById('modal-container');
    if (!container) return;

    const modal = document.createElement('div');
    modal.innerHTML = `
      <div class="modal-backdrop" data-modal="${id}"></div>
      <div class="modal" id="${id}">
        <div class="modal-header">
          <h3 class="modal-title">${title}</h3>
          ${closable ? '<button class="modal-close" aria-label="Close"><i class="ti ti-x"></i></button>' : ''}
        </div>
        <div class="modal-body">${content}</div>
        ${footer ? `<div class="modal-footer">${footer}</div>` : ''}
      </div>
    `;

    container.appendChild(modal);

    // Show modal
    setTimeout(() => {
      modal.querySelector('.modal-backdrop').classList.add('active');
      modal.querySelector('.modal').classList.add('active');
    }, 10);

    // Close handlers
    if (closable) {
      const closeBtn = modal.querySelector('.modal-close');
      const backdrop = modal.querySelector('.modal-backdrop');

      const close = () => {
        this.closeModal(id);
        if (onClose) onClose();
      };

      closeBtn.addEventListener('click', close);
      backdrop.addEventListener('click', close);

      // ESC key
      const escHandler = (e) => {
        if (e.key === 'Escape') {
          close();
          document.removeEventListener('keydown', escHandler);
        }
      };
      document.addEventListener('keydown', escHandler);
    }

    return id;
  },

  /**
   * Close modal
   * @param {string} id - Modal ID
   */
  closeModal(id) {
    const modal = document.getElementById(id);
    const backdrop = document.querySelector(`[data-modal="${id}"]`);
    
    if (modal) modal.classList.remove('active');
    if (backdrop) backdrop.classList.remove('active');

    setTimeout(() => {
      if (modal) modal.parentElement.remove();
    }, 300);
  },

  /**
   * Confirm dialog
   * @param {Object} options - Confirm options
   * @returns {Promise<boolean>}
   */
  confirm(options = {}) {
    const {
      title = 'Confirmação',
      message = 'Tem certeza?',
      confirmText = 'Confirmar',
      cancelText = 'Cancelar',
      type = 'primary' // primary, danger
    } = options;

    return new Promise((resolve) => {
      const content = `<p>${message}</p>`;
      const footer = `
        <button class="btn btn-ghost" data-action="cancel">${cancelText}</button>
        <button class="btn btn-${type}" data-action="confirm">${confirmText}</button>
      `;

      const id = this.modal({
        title,
        content,
        footer,
        closable: true,
        onClose: () => resolve(false)
      });

      // Wait for modal to be added to DOM
      setTimeout(() => {
        const modalEl = document.getElementById(id);
        if (!modalEl) return;

        const confirmBtn = modalEl.querySelector('[data-action="confirm"]');
        const cancelBtn = modalEl.querySelector('[data-action="cancel"]');

        confirmBtn.addEventListener('click', () => {
          this.closeModal(id);
          resolve(true);
        });

        cancelBtn.addEventListener('click', () => {
          this.closeModal(id);
          resolve(false);
        });
      }, 50);
    });
  },

  /**
   * Create card component
   * @param {Object} options - Card options
   * @returns {string} HTML string
   */
  card(options = {}) {
    const {
      title = '',
      actions = '',
      body = '',
      footer = '',
      className = ''
    } = options;

    return `
      <div class="card ${className}">
        ${title || actions ? `
          <div class="card-header">
            ${title ? `<h3 class="card-title">${title}</h3>` : ''}
            ${actions ? `<div class="card-actions">${actions}</div>` : ''}
          </div>
        ` : ''}
        ${body ? `<div class="card-body">${body}</div>` : ''}
        ${footer ? `<div class="card-footer">${footer}</div>` : ''}
      </div>
    `;
  },

  /**
   * Create stat card
   * @param {Object} options - Stat card options
   * @returns {string} HTML string
   */
  statCard(options = {}) {
    const {
      icon = 'ti-users',
      iconColor = 'primary',
      value = '0',
      label = '',
      change = null,
      changeType = 'positive'
    } = options;

    return `
      <div class="card stat-card">
        <div class="stat-icon ${iconColor}">
          <i class="ti ${icon}"></i>
        </div>
        <div class="stat-value">${value}</div>
        <div class="stat-label">${label}</div>
        ${change !== null ? `
          <div class="stat-change ${changeType}">
            <i class="ti ti-trending-${changeType === 'positive' ? 'up' : 'down'}"></i>
            ${Math.abs(change)}%
          </div>
        ` : ''}
      </div>
    `;
  },

  /**
   * Create table
   * @param {Object} options - Table options
   * @returns {string} HTML string
   */
  table(options = {}) {
    const {
      columns = [],
      data = [],
      actions = null,
      className = ''
    } = options;

    const headers = columns.map(col => `<th>${col.label}</th>`).join('');
    const actionsHeader = actions ? '<th>Ações</th>' : '';

    const rows = data.map(row => {
      const cells = columns.map(col => {
        const value = row[col.key];
        const formatted = col.format ? col.format(value, row) : value;
        return `<td data-label="${col.label}">${formatted}</td>`;
      }).join('');

      const actionsCells = actions ? `<td data-label="Ações">${actions(row)}</td>` : '';

      return `<tr>${cells}${actionsCells}</tr>`;
    }).join('');

    return `
      <div class="table-container ${className}">
        <table class="table">
          <thead>
            <tr>${headers}${actionsHeader}</tr>
          </thead>
          <tbody>
            ${rows || '<tr><td colspan="100%" class="text-center">Nenhum registro encontrado</td></tr>'}
          </tbody>
        </table>
      </div>
    `;
  },

  /**
   * Create pagination
   * @param {Object} options - Pagination options
   * @returns {string} HTML string
   */
  pagination(options = {}) {
    const {
      currentPage = 1,
      totalPages = 1,
      onPageChange = () => {}
    } = options;

    if (totalPages <= 1) return '';

    const pages = [];
    const maxVisible = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2));
    let endPage = Math.min(totalPages, startPage + maxVisible - 1);

    if (endPage - startPage < maxVisible - 1) {
      startPage = Math.max(1, endPage - maxVisible + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    const buttons = pages.map(page => `
      <button class="pagination-btn ${page === currentPage ? 'active' : ''}" 
              data-page="${page}"
              ${page === currentPage ? 'disabled' : ''}>
        ${page}
      </button>
    `).join('');

    const html = `
      <div class="pagination">
        <button class="pagination-btn" data-page="${currentPage - 1}" ${currentPage === 1 ? 'disabled' : ''}>
          <i class="ti ti-chevron-left"></i>
        </button>
        ${buttons}
        <button class="pagination-btn" data-page="${currentPage + 1}" ${currentPage === totalPages ? 'disabled' : ''}>
          <i class="ti ti-chevron-right"></i>
        </button>
      </div>
    `;

    // Attach event listeners after rendering
    setTimeout(() => {
      document.querySelectorAll('.pagination-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const page = parseInt(e.currentTarget.dataset.page);
          if (page >= 1 && page <= totalPages) {
            onPageChange(page);
          }
        });
      });
    }, 0);

    return html;
  },

  /**
   * Create badge
   * @param {Object} options - Badge options
   * @returns {string} HTML string
   */
  badge(options = {}) {
    const { text = '', type = 'primary' } = options;
    return `<span class="badge badge-${type}">${text}</span>`;
  },

  /**
   * Create alert
   * @param {Object} options - Alert options
   * @returns {string} HTML string
   */
  alert(options = {}) {
    const {
      title = '',
      message = '',
      type = 'info',
      icon = true
    } = options;

    const icons = {
      primary: 'ti-info-circle',
      success: 'ti-check',
      danger: 'ti-alert-circle',
      warning: 'ti-alert-triangle'
    };

    return `
      <div class="alert alert-${type}">
        ${icon ? `<i class="alert-icon ti ${icons[type]}"></i>` : ''}
        <div class="alert-content">
          ${title ? `<div class="alert-title">${title}</div>` : ''}
          <div class="alert-message">${message}</div>
        </div>
      </div>
    `;
  },

  /**
   * Create empty state
   * @param {Object} options - Empty state options
   * @returns {string} HTML string
   */
  emptyState(options = {}) {
    const {
      icon = 'ti-folder-off',
      title = 'Nenhum dado encontrado',
      message = 'Não há itens para exibir no momento.',
      action = null
    } = options;

    return `
      <div class="empty-state">
        <div class="empty-state-icon">
          <i class="ti ${icon}"></i>
        </div>
        <h3 class="empty-state-title">${title}</h3>
        <p class="empty-state-text">${message}</p>
        ${action ? `<div>${action}</div>` : ''}
      </div>
    `;
  },

  /**
   * Create skeleton loader
   * @param {Object} options - Skeleton options
   * @returns {string} HTML string
   */
  skeleton(options = {}) {
    const { type = 'text', count = 3 } = options;

    if (type === 'card') {
      return `
        <div class="card">
          <div class="card-body">
            <div class="skeleton skeleton-text"></div>
            <div class="skeleton skeleton-text"></div>
            <div class="skeleton skeleton-text"></div>
          </div>
        </div>
      `;
    }

    if (type === 'table') {
      const rows = Array.from({ length: count }, () => `
        <tr>
          <td><div class="skeleton skeleton-text"></div></td>
          <td><div class="skeleton skeleton-text"></div></td>
          <td><div class="skeleton skeleton-text"></div></td>
        </tr>
      `).join('');

      return `
        <div class="table-container">
          <table class="table">
            <tbody>${rows}</tbody>
          </table>
        </div>
      `;
    }

    return Array.from({ length: count }, () => 
      `<div class="skeleton skeleton-text"></div>`
    ).join('');
  },

  /**
   * Create dropdown menu
   * @param {Object} options - Dropdown options
   * @returns {string} HTML string
   */
  dropdown(options = {}) {
    const {
      items = [],
      triggerContent = 'Menu'
    } = options;

    const id = Utils.generateId();
    const menuItems = items.map(item => {
      if (item.divider) {
        return '<div class="dropdown-divider"></div>';
      }
      return `
        <button class="dropdown-item" data-action="${item.action || ''}">
          ${item.icon ? `<i class="ti ${item.icon}"></i>` : ''}
          ${item.label}
        </button>
      `;
    }).join('');

    const html = `
      <div class="dropdown" id="${id}">
        <button class="dropdown-toggle btn btn-ghost">
          ${triggerContent}
          <i class="ti ti-chevron-down"></i>
        </button>
        <div class="dropdown-menu">
          ${menuItems}
        </div>
      </div>
    `;

    // Attach event listeners after rendering
    setTimeout(() => {
      const dropdown = document.getElementById(id);
      if (!dropdown) return;

      const toggle = dropdown.querySelector('.dropdown-toggle');
      const menu = dropdown.querySelector('.dropdown-menu');

      toggle.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdown.classList.toggle('active');
      });

      // Close when clicking outside
      document.addEventListener('click', () => {
        dropdown.classList.remove('active');
      });

      // Handle item clicks
      dropdown.querySelectorAll('.dropdown-item').forEach(item => {
        item.addEventListener('click', (e) => {
          const action = e.currentTarget.dataset.action;
          if (action && options.onSelect) {
            options.onSelect(action);
          }
          dropdown.classList.remove('active');
        });
      });
    }, 0);

    return html;
  },

  /**
   * Create tabs
   * @param {Object} options - Tabs options
   * @returns {Object} { html, init }
   */
  tabs(options = {}) {
    const {
      tabs = [],
      activeTab = 0
    } = options;

    const id = Utils.generateId();
    
    const tabButtons = tabs.map((tab, index) => `
      <button class="tab-btn ${index === activeTab ? 'active' : ''}" 
              data-tab="${index}">
        ${tab.label}
      </button>
    `).join('');

    const tabContents = tabs.map((tab, index) => `
      <div class="tab-content ${index === activeTab ? 'active' : ''}" 
           data-tab-content="${index}">
        ${tab.content}
      </div>
    `).join('');

    const html = `
      <div class="tabs-container" id="${id}">
        <div class="tabs">${tabButtons}</div>
        <div class="tabs-content">${tabContents}</div>
      </div>
    `;

    const init = () => {
      const container = document.getElementById(id);
      if (!container) return;

      container.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const tabIndex = e.currentTarget.dataset.tab;
          
          // Remove active class from all
          container.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
          container.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
          
          // Add active to clicked
          e.currentTarget.classList.add('active');
          container.querySelector(`[data-tab-content="${tabIndex}"]`).classList.add('active');
        });
      });
    };

    return { html, init };
  }
};

// Export para uso global
window.Components = Components;