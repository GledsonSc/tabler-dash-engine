/**
 * Router Module
 * Hash-based routing system
 */

class Router {
  constructor() {
    this.routes = {};
    this.currentRoute = null;
    this.init();
  }

  /**
   * Initialize router
   */
  init() {
    // Listen to hash changes
    window.addEventListener('hashchange', () => this.handleRoute());
    window.addEventListener('load', () => this.handleRoute());
  }

  /**
   * Register route
   * @param {string} path - Route path
   * @param {Function} handler - Route handler
   */
  register(path, handler) {
    this.routes[path] = handler;
  }

  /**
   * Handle current route
   */
  async handleRoute() {
    const hash = window.location.hash.slice(1) || '/dashboard';
    const [path, ...params] = hash.split('/').filter(Boolean);
    const route = `/${path}`;

    // Update nav active state
    this.updateNavigation(route);

    // Update breadcrumb and title
    this.updatePageInfo(route);

    if (this.routes[route]) {
      this.currentRoute = route;
      State.setLoading(true);
      
      try {
        await this.routes[route](params);
      } catch (error) {
        console.error('Route error:', error);
        this.renderError(error);
      } finally {
        State.setLoading(false);
      }
    } else {
      this.render404();
    }
  }

  /**
   * Navigate to route
   * @param {string} path - Route path
   */
  navigate(path) {
    window.location.hash = path;
  }

  /**
   * Update navigation active state
   * @param {string} route - Current route
   */
  updateNavigation(route) {
    document.querySelectorAll('.nav-link').forEach(link => {
      const linkRoute = link.getAttribute('data-route');
      if (linkRoute === route.slice(1)) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  }

  /**
   * Update page title and breadcrumb
   * @param {string} route - Current route
   */
  updatePageInfo(route) {
    const routeInfo = {
      '/dashboard': { title: 'Dashboard', breadcrumb: ['Home', 'Dashboard'] },
      '/analytics': { title: 'Analytics', breadcrumb: ['Home', 'Analytics'] },
      '/users': { title: 'Users', breadcrumb: ['Home', 'Users'] },
      '/settings': { title: 'Settings', breadcrumb: ['Home', 'Settings'] }
    };

    const info = routeInfo[route] || { title: 'Page', breadcrumb: ['Home'] };
    
    // Update title
    const titleEl = document.getElementById('page-title');
    if (titleEl) titleEl.textContent = info.title;
    document.title = `${info.title} - Tabler Dashboard`;

    // Update breadcrumb
    const breadcrumbEl = document.getElementById('breadcrumb-list');
    if (breadcrumbEl) {
      breadcrumbEl.innerHTML = info.breadcrumb.map((item, index) => {
        const isLast = index === info.breadcrumb.length - 1;
        return `
          <li ${isLast ? 'class="active"' : ''}>
            ${isLast ? item : `<a href="#/dashboard">${item}</a>`}
          </li>
        `;
      }).join('');
    }
  }

  /**
   * Render content
   * @param {string} html - HTML content
   */
  render(html) {
    const content = document.getElementById('page-content');
    if (content) {
      content.innerHTML = html;
      content.classList.add('page-transition-enter');
      setTimeout(() => content.classList.remove('page-transition-enter'), 300);
    }
  }

  /**
   * Render 404 page
   */
  render404() {
    this.render(Components.emptyState({
      icon: 'ti-error-404',
      title: 'Página não encontrada',
      message: 'A página que você está procurando não existe.',
      action: '<button class="btn btn-primary" onclick="Router.navigate(\'/dashboard\')">Voltar ao Dashboard</button>'
    }));
  }

  /**
   * Render error page
   * @param {Error} error - Error object
   */
  renderError(error) {
    this.render(Components.alert({
      type: 'danger',
      title: 'Erro',
      message: error.message || 'Ocorreu um erro ao carregar a página.'
    }));
  }
}

// Create router instance
const router = new Router();

// ===== ROUTE HANDLERS =====

/**
 * Dashboard Route
 */
router.register('/dashboard', async () => {
  try {
    // Fetch stats
    const stats = await API.get('/stats');
    State.updateStats(stats);

    const html = `
      <div class="row">
        <div class="col-12 col-md-6 col-lg-3">
          ${Components.statCard({
            icon: 'ti-users',
            iconColor: 'primary',
            value: Utils.formatNumber(stats.users),
            label: 'Total de Usuários',
            change: stats.growth,
            changeType: 'positive'
          })}
        </div>
        <div class="col-12 col-md-6 col-lg-3">
          ${Components.statCard({
            icon: 'ti-currency-dollar',
            iconColor: 'success',
            value: Utils.formatCurrency(stats.revenue),
            label: 'Receita Total',
            change: 8.2,
            changeType: 'positive'
          })}
        </div>
        <div class="col-12 col-md-6 col-lg-3">
          ${Components.statCard({
            icon: 'ti-shopping-cart',
            iconColor: 'warning',
            value: Utils.formatNumber(stats.orders),
            label: 'Pedidos',
            change: 2.5,
            changeType: 'negative'
          })}
        </div>
        <div class="col-12 col-md-6 col-lg-3">
          ${Components.statCard({
            icon: 'ti-chart-line',
            iconColor: 'danger',
            value: `${stats.growth}%`,
            label: 'Crescimento',
            change: stats.growth,
            changeType: 'positive'
          })}
        </div>
      </div>

      <div class="row">
        <div class="col-12 col-lg-8">
          ${Components.card({
            title: 'Atividade Recente',
            body: `
              <p>Gráfico de atividade seria renderizado aqui.</p>
              <p class="text-muted">Integre com uma biblioteca de gráficos como Chart.js ou Recharts.</p>
            `
          })}
        </div>
        <div class="col-12 col-lg-4">
          ${Components.card({
            title: 'Usuários Online',
            body: `
              <div class="d-flex flex-column gap-3">
                <div class="d-flex align-items-center gap-3">
                  <img src="./assets/images/avatar.png" alt="User" class="avatar avatar-sm">
                  <div>
                    <div class="fw-semibold">John Doe</div>
                    <div class="text-muted" style="font-size: 0.75rem;">Online agora</div>
                  </div>
                </div>
                <div class="d-flex align-items-center gap-3">
                  <img src="./assets/images/avatar.png" alt="User" class="avatar avatar-sm">
                  <div>
                    <div class="fw-semibold">Jane Smith</div>
                    <div class="text-muted" style="font-size: 0.75rem;">há 5 minutos</div>
                  </div>
                </div>
                <div class="d-flex align-items-center gap-3">
                  <img src="./assets/images/avatar.png" alt="User" class="avatar avatar-sm">
                  <div>
                    <div class="fw-semibold">Bob Johnson</div>
                    <div class="text-muted" style="font-size: 0.75rem;">há 10 minutos</div>
                  </div>
                </div>
              </div>
            `
          })}
        </div>
      </div>
    `;

    router.render(html);
  } catch (error) {
    router.renderError(error);
  }
});

/**
 * Analytics Route
 */
router.register('/analytics', async () => {
  try {
    const analytics = await API.get('/analytics');

    const html = `
      <div class="row">
        <div class="col-12">
          ${Components.card({
            title: 'Analytics Dashboard',
            body: `
              <p>Dados de analytics carregados com sucesso!</p>
              <p class="text-muted">Total de visualizações: ${analytics.pageViews.reduce((sum, item) => sum + item.views, 0)}</p>
              <p class="text-muted">Aqui você pode integrar gráficos detalhados usando Chart.js, Plotly ou outra biblioteca.</p>
            `
          })}
        </div>
      </div>
    `;

    router.render(html);
  } catch (error) {
    router.renderError(error);
  }
});

/**
 * Users Route
 */
router.register('/users', async () => {
  try {
    const users = await API.get('/users');
    State.setUsers(users);

    renderUsersTable();
  } catch (error) {
    router.renderError(error);
  }
});

/**
 * Render users table
 */
function renderUsersTable() {
  const { data, totalPages, currentPage } = State.getFilteredUsers();

  const tableHtml = Components.table({
    columns: [
      { key: 'name', label: 'Nome' },
      { key: 'email', label: 'Email' },
      { key: 'role', label: 'Função' },
      { 
        key: 'status', 
        label: 'Status',
        format: (value) => Components.badge({
          text: value === 'active' ? 'Ativo' : 'Inativo',
          type: value === 'active' ? 'success' : 'secondary'
        })
      },
      { 
        key: 'createdAt', 
        label: 'Criado em',
        format: (value) => Utils.formatDate(value)
      }
    ],
    data,
    actions: (row) => `
      <div class="table-actions">
        <button class="btn-icon" onclick="editUser(${row.id})" title="Editar">
          <i class="ti ti-edit"></i>
        </button>
        <button class="btn-icon" onclick="deleteUser(${row.id})" title="Excluir">
          <i class="ti ti-trash"></i>
        </button>
      </div>
    `
  });

  const paginationHtml = Components.pagination({
    currentPage,
    totalPages,
    onPageChange: (page) => {
      State.updatePagination({ page });
      renderUsersTable();
    }
  });

  const html = `
    <div class="row">
      <div class="col-12">
        ${Components.card({
          title: 'Usuários',
          actions: `
            <button class="btn btn-primary" onclick="createUser()">
              <i class="ti ti-plus"></i>
              Novo Usuário
            </button>
          `,
          body: `
            <div class="mb-4">
              <input type="text" 
                     class="form-control" 
                     placeholder="Buscar usuários..."
                     id="search-input"
                     value="${State.getState('filters').search}">
            </div>
            ${tableHtml}
            ${paginationHtml}
          `
        })}
      </div>
    </div>
  `;

  router.render(html);

  // Add search listener
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', Utils.debounce((e) => {
      State.updateFilters({ search: e.target.value });
      renderUsersTable();
    }, 300));
  }
}

/**
 * Settings Route
 */
router.register('/settings', () => {
  const html = `
    <div class="row">
      <div class="col-12 col-lg-8">
        ${Components.card({
          title: 'Configurações',
          body: `
            <form id="settings-form">
              <div class="form-group">
                <label class="form-label">Nome</label>
                <input type="text" class="form-control" value="John Doe">
              </div>
              <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" class="form-control" value="john@example.com">
              </div>
              <div class="form-group">
                <label class="form-label">Tema</label>
                <select class="form-control" id="theme-select">
                  <option value="light" ${State.getState('theme') === 'light' ? 'selected' : ''}>Claro</option>
                  <option value="dark" ${State.getState('theme') === 'dark' ? 'selected' : ''}>Escuro</option>
                </select>
              </div>
              <button type="submit" class="btn btn-primary">Salvar Alterações</button>
            </form>
          `
        })}
      </div>
    </div>
  `;

  router.render(html);

  // Add form listener
  const form = document.getElementById('settings-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      Components.toast({
        type: 'success',
        title: 'Sucesso',
        message: 'Configurações salvas com sucesso!'
      });
    });
  }

  // Theme selector
  const themeSelect = document.getElementById('theme-select');
  if (themeSelect) {
    themeSelect.addEventListener('change', (e) => {
      const theme = e.target.value;
      State.setState({ theme });
      State.applyTheme(theme);
      Utils.storage.set('theme', theme);
    });
  }
});

// ===== GLOBAL FUNCTIONS =====

window.editUser = async (id) => {
  Components.toast({
    type: 'info',
    message: `Editando usuário ${id}`
  });
};

window.deleteUser = async (id) => {
  const confirmed = await Components.confirm({
    title: 'Excluir Usuário',
    message: 'Tem certeza que deseja excluir este usuário?',
    type: 'danger',
    confirmText: 'Excluir'
  });

  if (confirmed) {
    try {
      await API.delete(`/users/${id}`);
      const users = await API.get('/users');
      State.setUsers(users);
      renderUsersTable();
      
      Components.toast({
        type: 'success',
        title: 'Sucesso',
        message: 'Usuário excluído com sucesso!'
      });
    } catch (error) {
      Components.toast({
        type: 'error',
        title: 'Erro',
        message: 'Não foi possível excluir o usuário.'
      });
    }
  }
};

window.createUser = () => {
  Components.toast({
    type: 'info',
    message: 'Funcionalidade de criar usuário em desenvolvimento'
  });
};

// Export router
window.Router = router;