/**
 * Utility Functions
 * Funções auxiliares reutilizáveis
 */

const Utils = {
  /**
   * Debounce function - executa após delay sem chamadas
   * @param {Function} func - Função a ser executada
   * @param {number} wait - Tempo de espera em ms
   * @returns {Function}
   */
  debounce(func, wait = 300) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  },

  /**
   * Throttle function - limita execução a intervalo
   * @param {Function} func - Função a ser executada
   * @param {number} limit - Intervalo mínimo em ms
   * @returns {Function}
   */
  throttle(func, limit = 300) {
    let inThrottle;
    return function(...args) {
      if (!inThrottle) {
        func.apply(this, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  },

  /**
   * Format currency
   * @param {number} value - Valor numérico
   * @param {string} currency - Código da moeda (default: BRL)
   * @returns {string}
   */
  formatCurrency(value, currency = 'BRL') {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: currency
    }).format(value);
  },

  /**
   * Format date
   * @param {Date|string} date - Data
   * @param {string} format - Formato (short, medium, long, full)
   * @returns {string}
   */
  formatDate(date, format = 'short') {
    const dateObj = date instanceof Date ? date : new Date(date);
    const options = {
      short: { year: 'numeric', month: '2-digit', day: '2-digit' },
      medium: { year: 'numeric', month: 'short', day: 'numeric' },
      long: { year: 'numeric', month: 'long', day: 'numeric' },
      full: { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }
    };
    return new Intl.DateTimeFormat('pt-BR', options[format] || options.short).format(dateObj);
  },

  /**
   * Format relative time (há 2 horas, 3 dias atrás)
   * @param {Date|string} date - Data
   * @returns {string}
   */
  formatRelativeTime(date) {
    const dateObj = date instanceof Date ? date : new Date(date);
    const now = new Date();
    const diff = now - dateObj;
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    const months = Math.floor(days / 30);
    const years = Math.floor(days / 365);

    if (seconds < 60) return 'agora';
    if (minutes < 60) return `há ${minutes} minuto${minutes > 1 ? 's' : ''}`;
    if (hours < 24) return `há ${hours} hora${hours > 1 ? 's' : ''}`;
    if (days < 30) return `há ${days} dia${days > 1 ? 's' : ''}`;
    if (months < 12) return `há ${months} ${months > 1 ? 'meses' : 'mês'}`;
    return `há ${years} ano${years > 1 ? 's' : ''}`;
  },

  /**
   * Format number with abbreviation (1k, 1M, 1B)
   * @param {number} num - Número
   * @returns {string}
   */
  formatNumber(num) {
    if (num >= 1000000000) return (num / 1000000000).toFixed(1) + 'B';
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'k';
    return num.toString();
  },

  /**
   * Generate unique ID
   * @returns {string}
   */
  generateId() {
    return `id_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  },

  /**
   * Capitalize first letter
   * @param {string} str - String
   * @returns {string}
   */
  capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
  },

  /**
   * Truncate text
   * @param {string} str - Texto
   * @param {number} length - Tamanho máximo
   * @returns {string}
   */
  truncate(str, length = 50) {
    return str.length > length ? str.substring(0, length) + '...' : str;
  },

  /**
   * Deep clone object
   * @param {Object} obj - Objeto a clonar
   * @returns {Object}
   */
  deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
  },

  /**
   * Check if object is empty
   * @param {Object} obj - Objeto
   * @returns {boolean}
   */
  isEmpty(obj) {
    return Object.keys(obj).length === 0;
  },

  /**
   * Group array by property
   * @param {Array} array - Array de objetos
   * @param {string} key - Propriedade para agrupar
   * @returns {Object}
   */
  groupBy(array, key) {
    return array.reduce((result, item) => {
      const group = item[key];
      result[group] = result[group] || [];
      result[group].push(item);
      return result;
    }, {});
  },

  /**
   * Sort array by property
   * @param {Array} array - Array de objetos
   * @param {string} key - Propriedade para ordenar
   * @param {string} order - 'asc' ou 'desc'
   * @returns {Array}
   */
  sortBy(array, key, order = 'asc') {
    return [...array].sort((a, b) => {
      const valueA = a[key];
      const valueB = b[key];
      if (order === 'asc') {
        return valueA > valueB ? 1 : valueA < valueB ? -1 : 0;
      } else {
        return valueA < valueB ? 1 : valueA > valueB ? -1 : 0;
      }
    });
  },

  /**
   * Filter array by search term
   * @param {Array} array - Array de objetos
   * @param {string} searchTerm - Termo de busca
   * @param {Array} keys - Propriedades para buscar
   * @returns {Array}
   */
  search(array, searchTerm, keys) {
    const term = searchTerm.toLowerCase();
    return array.filter(item => {
      return keys.some(key => {
        const value = item[key];
        return value && value.toString().toLowerCase().includes(term);
      });
    });
  },

  /**
   * Paginate array
   * @param {Array} array - Array
   * @param {number} page - Página atual (1-based)
   * @param {number} perPage - Itens por página
   * @returns {Object} { data, totalPages, currentPage }
   */
  paginate(array, page = 1, perPage = 10) {
    const totalPages = Math.ceil(array.length / perPage);
    const start = (page - 1) * perPage;
    const end = start + perPage;
    return {
      data: array.slice(start, end),
      totalPages,
      currentPage: page,
      hasNext: page < totalPages,
      hasPrev: page > 1
    };
  },

  /**
   * Validate email
   * @param {string} email - Email
   * @returns {boolean}
   */
  validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  },

  /**
   * Validate URL
   * @param {string} url - URL
   * @returns {boolean}
   */
  validateURL(url) {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  },

  /**
   * Get query params from URL
   * @returns {Object}
   */
  getQueryParams() {
    const params = {};
    const searchParams = new URLSearchParams(window.location.search);
    for (const [key, value] of searchParams) {
      params[key] = value;
    }
    return params;
  },

  /**
   * Set query param in URL
   * @param {string} key - Chave
   * @param {string} value - Valor
   */
  setQueryParam(key, value) {
    const url = new URL(window.location);
    url.searchParams.set(key, value);
    window.history.pushState({}, '', url);
  },

  /**
   * Copy text to clipboard
   * @param {string} text - Texto
   * @returns {Promise}
   */
  async copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // Fallback para navegadores antigos
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      const success = document.execCommand('copy');
      document.body.removeChild(textarea);
      return success;
    }
  },

  /**
   * Download file
   * @param {string} content - Conteúdo do arquivo
   * @param {string} filename - Nome do arquivo
   * @param {string} type - Tipo MIME
   */
  downloadFile(content, filename, type = 'text/plain') {
    const blob = new Blob([content], { type });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    window.URL.revokeObjectURL(url);
  },

  /**
   * Detect if mobile device
   * @returns {boolean}
   */
  isMobile() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  },

  /**
   * Get scroll position
   * @returns {Object} { x, y }
   */
  getScrollPosition() {
    return {
      x: window.pageXOffset || document.documentElement.scrollLeft,
      y: window.pageYOffset || document.documentElement.scrollTop
    };
  },

  /**
   * Smooth scroll to element
   * @param {string|HTMLElement} target - Seletor ou elemento
   * @param {number} offset - Offset em pixels
   */
  scrollTo(target, offset = 0) {
    const element = typeof target === 'string' ? document.querySelector(target) : target;
    if (!element) return;
    
    const top = element.getBoundingClientRect().top + window.pageYOffset - offset;
    window.scrollTo({
      top,
      behavior: 'smooth'
    });
  },

  /**
   * Check if element is in viewport
   * @param {HTMLElement} element - Elemento
   * @returns {boolean}
   */
  isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  },

  /**
   * Add ripple effect to element
   * @param {HTMLElement} element - Elemento
   * @param {Event} event - Evento de clique
   */
  addRipple(element, event) {
    const ripple = document.createElement('span');
    ripple.classList.add('ripple');
    
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;
    
    ripple.style.width = ripple.style.height = `${size}px`;
    ripple.style.left = `${x}px`;
    ripple.style.top = `${y}px`;
    
    element.appendChild(ripple);
    
    setTimeout(() => ripple.remove(), 600);
  },

  /**
   * Local Storage with expiration
   */
  storage: {
    set(key, value, expirationMinutes = null) {
      const data = {
        value,
        expiration: expirationMinutes ? Date.now() + (expirationMinutes * 60 * 1000) : null
      };
      localStorage.setItem(key, JSON.stringify(data));
    },

    get(key) {
      const item = localStorage.getItem(key);
      if (!item) return null;

      const data = JSON.parse(item);
      if (data.expiration && Date.now() > data.expiration) {
        localStorage.removeItem(key);
        return null;
      }

      return data.value;
    },

    remove(key) {
      localStorage.removeItem(key);
    },

    clear() {
      localStorage.clear();
    }
  },

  /**
   * Random color generator
   * @returns {string} Hex color
   */
  randomColor() {
    return '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
  },

  /**
   * Wait/sleep function
   * @param {number} ms - Milliseconds
   * @returns {Promise}
   */
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  },

  /**
   * Retry async function
   * @param {Function} fn - Função async
   * @param {number} retries - Número de tentativas
   * @param {number} delay - Delay entre tentativas (ms)
   * @returns {Promise}
   */
  async retry(fn, retries = 3, delay = 1000) {
    try {
      return await fn();
    } catch (error) {
      if (retries > 0) {
        await this.sleep(delay);
        return this.retry(fn, retries - 1, delay);
      }
      throw error;
    }
  },

  /**
   * Parse CSV string
   * @param {string} csv - CSV content
   * @returns {Array} Array of objects
   */
  parseCSV(csv) {
    const lines = csv.split('\n').filter(line => line.trim());
    const headers = lines[0].split(',').map(h => h.trim());
    
    return lines.slice(1).map(line => {
      const values = line.split(',').map(v => v.trim());
      const obj = {};
      headers.forEach((header, i) => {
        obj[header] = values[i];
      });
      return obj;
    });
  },

  /**
   * Convert object to CSV
   * @param {Array} data - Array of objects
   * @returns {string} CSV string
   */
  toCSV(data) {
    if (!data.length) return '';
    
    const headers = Object.keys(data[0]);
    const rows = data.map(obj => 
      headers.map(header => JSON.stringify(obj[header] || '')).join(',')
    );
    
    return [headers.join(','), ...rows].join('\n');
  }
};

// Export para uso global
window.Utils = Utils;