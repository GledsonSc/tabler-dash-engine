/**
 * API Module
 * Gerencia chamadas API e dados mock
 */

const API = {
  // Base URL - alterar para API real
  baseURL: 'https://api.example.com',
  
  // Mock mode - mudar para false quando conectar API real
  mockMode: true,
  
  /**
   * HTTP Request wrapper
   * @param {string} endpoint - API endpoint
   * @param {Object} options - Fetch options
   * @returns {Promise}
   */
  async request(endpoint, options = {}) {
    if (this.mockMode) {
      return this.mockRequest(endpoint, options);
    }
    
    const url = `${this.baseURL}${endpoint}`;
    const token = Utils.storage.get('token');
    
    const config = {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }),
        ...options.headers
      }
    };
    
    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  },

  /**
   * Mock request handler
   * @param {string} endpoint - Endpoint
   * @param {Object} options - Options
   * @returns {Promise}
   */
  async mockRequest(endpoint, options = {}) {
    // Simulate network delay
    await Utils.sleep(500 + Math.random() * 500);
    
    const method = options.method || 'GET';
    
    // Route mock requests
    if (endpoint === '/stats' && method === 'GET') {
      return this.mockData.getStats();
    }
    
    if (endpoint === '/users' && method === 'GET') {
      return this.mockData.getUsers();
    }
    
    if (endpoint.match(/\/users\/\d+/) && method === 'GET') {
      const id = parseInt(endpoint.split('/').pop());
      return this.mockData.getUserById(id);
    }
    
    if (endpoint === '/users' && method === 'POST') {
      return this.mockData.createUser(JSON.parse(options.body));
    }
    
    if (endpoint.match(/\/users\/\d+/) && method === 'PUT') {
      const id = parseInt(endpoint.split('/').pop());
      return this.mockData.updateUser(id, JSON.parse(options.body));
    }
    
    if (endpoint.match(/\/users\/\d+/) && method === 'DELETE') {
      const id = parseInt(endpoint.split('/').pop());
      return this.mockData.deleteUser(id);
    }
    
    if (endpoint === '/analytics' && method === 'GET') {
      return this.mockData.getAnalytics();
    }
    
    throw new Error(`Mock endpoint not found: ${method} ${endpoint}`);
  },

  /**
   * GET request
   */
  get(endpoint, options = {}) {
    return this.request(endpoint, { ...options, method: 'GET' });
  },

  /**
   * POST request
   */
  post(endpoint, data, options = {}) {
    return this.request(endpoint, {
      ...options,
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  /**
   * PUT request
   */
  put(endpoint, data, options = {}) {
    return this.request(endpoint, {
      ...options,
      method: 'PUT',
      body: JSON.stringify(data)
    });
  },

  /**
   * DELETE request
   */
  delete(endpoint, options = {}) {
    return this.request(endpoint, { ...options, method: 'DELETE' });
  },

  // ===== MOCK DATA =====
  mockData: {
    users: [
      { id: 1, name: 'John Doe', email: 'john@example.com', role: 'Admin', status: 'active', avatar: './assets/images/avatar.png', createdAt: '2024-01-15' },
      { id: 2, name: 'Jane Smith', email: 'jane@example.com', role: 'User', status: 'active', avatar: './assets/images/avatar.png', createdAt: '2024-02-20' },
      { id: 3, name: 'Bob Johnson', email: 'bob@example.com', role: 'User', status: 'inactive', avatar: './assets/images/avatar.png', createdAt: '2024-03-10' },
      { id: 4, name: 'Alice Williams', email: 'alice@example.com', role: 'Manager', status: 'active', avatar: './assets/images/avatar.png', createdAt: '2024-01-25' },
      { id: 5, name: 'Charlie Brown', email: 'charlie@example.com', role: 'User', status: 'active', avatar: './assets/images/avatar.png', createdAt: '2024-02-15' },
      { id: 6, name: 'Diana Prince', email: 'diana@example.com', role: 'Admin', status: 'active', avatar: './assets/images/avatar.png', createdAt: '2024-01-05' },
      { id: 7, name: 'Edward Norton', email: 'edward@example.com', role: 'User', status: 'inactive', avatar: './assets/images/avatar.png', createdAt: '2024-03-01' },
      { id: 8, name: 'Fiona Green', email: 'fiona@example.com', role: 'Manager', status: 'active', avatar: './assets/images/avatar.png', createdAt: '2024-02-10' }
    ],

    getStats() {
      return {
        users: 1247,
        revenue: 45231.89,
        orders: 328,
        growth: 12.5
      };
    },

    getUsers() {
      return [...this.users];
    },

    getUserById(id) {
      const user = this.users.find(u => u.id === id);
      if (!user) throw new Error('User not found');
      return { ...user };
    },

    createUser(userData) {
      const newUser = {
        id: Math.max(...this.users.map(u => u.id)) + 1,
        ...userData,
        avatar: './assets/images/avatar.png',
        createdAt: new Date().toISOString().split('T')[0]
      };
      this.users.push(newUser);
      return newUser;
    },

    updateUser(id, userData) {
      const index = this.users.findIndex(u => u.id === id);
      if (index === -1) throw new Error('User not found');
      
      this.users[index] = { ...this.users[index], ...userData };
      return this.users[index];
    },

    deleteUser(id) {
      const index = this.users.findIndex(u => u.id === id);
      if (index === -1) throw new Error('User not found');
      
      this.users.splice(index, 1);
      return { success: true };
    },

    getAnalytics() {
      return {
        pageViews: [
          { date: '2024-01-01', views: 1200 },
          { date: '2024-01-02', views: 1350 },
          { date: '2024-01-03', views: 1100 },
          { date: '2024-01-04', views: 1450 },
          { date: '2024-01-05', views: 1600 },
          { date: '2024-01-06', views: 1400 },
          { date: '2024-01-07', views: 1550 }
        ],
        usersByRole: [
          { role: 'Admin', count: 15 },
          { role: 'Manager', count: 45 },
          { role: 'User', count: 187 }
        ],
        revenueByMonth: [
          { month: 'Jan', revenue: 35000 },
          { month: 'Feb', revenue: 42000 },
          { month: 'Mar', revenue: 38000 },
          { month: 'Apr', revenue: 45000 },
          { month: 'May', revenue: 52000 },
          { month: 'Jun', revenue: 48000 }
        ]
      };
    }
  }
};

// Export para uso global
window.API = API;